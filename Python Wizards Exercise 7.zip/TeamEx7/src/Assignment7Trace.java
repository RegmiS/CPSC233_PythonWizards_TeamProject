
public class Assignment7Trace {

	public static void main(String[] args) {

		BankAccount b1 = new ChequingAccount(new Customer("John Doe", 1001), 100.0, 10.0);
		// creates a new chequingAccount with an accountHolder, a balance of 100.0 and fee of 10.0
		BankAccount b2 = new SavingsAccount(new Customer("Jane Doe", 2002), 500.0, 5.0);
		// creates a new SavingsAccount with an accountHolder, a balance of 500.0 and an interest rate of 5.0
		
		// whenever monthEndUpdate() is called it calls on getMonthlyFeesAndInterest() and adjusts the balance by adding
		// what is returned(by getMonthlyFeesAndInterest):
		
		// since b1 is a ChequingAccount and the balance is positive getMonthlyFeesAndInterest will return 0.0 so
		// monthEndUpdate will not change anything
		
		// since b2 is a SavingsAccount getMonthlyFeesAndInterest will return the fee of 5 for having a balance below 1000
		// plus the interest fee so the balance will increase by 5.0/12.0 / 100.0 * balance and decrease by 5.0
		
		b1.monthEndUpdate();
		b2.monthEndUpdate();
		
		System.out.println(b1.getBalance() + ", " + b2.getBalance());
	}

}
